//RGB矩阵
#define WS2812_DI_PIN D7
#define RGB_MATRIX_LED_COUNT 14
#define RGBLIGHT_LIMIT_VAL 180

//软件消抖
#define DEBOUNCE 5

//旋钮
#define ENCODERS_PAD_A { B2 }
#define ENCODERS_PAD_B { B3 }
#define ENCODER_DIRECTION_FLIP//软件反转
#define ENCODER_RESOLUTION 4
