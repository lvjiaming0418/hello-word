#include QMK_KEYBOARD_H

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
	[0] = LAYOUT_horizontal(
		KC_VOLU , _______ , _______ , _______ ,
        KC_MUTE , KC_MPRV , KC_MPLY , KC_MNXT ,
        KC_MUTE , KC_MPRV , KC_MPLY , 
        KC_VOLD , _______ , _______ , KC_MS_BTN1
    )
};

/*RGB Matrix*/
#ifdef RGB_MATRIX_ENABLE
led_config_t g_led_config = { {
    { NO_LED, 0, 1, 2 },
    { 6, 5, 4, 3 },
    { 7, 8, 9 },
    { 13, 12, 11, 10 }
}, {
    { 75, 0 }, { 149, 0 }, { 224, 0 }, { 224, 21 }, { 149, 21 }, { 75, 21 }, { 0, 21 }, { 0, 43 }, { 75, 43 }, { 149, 43 }, { 224, 53 }, { 149, 64 }, { 75, 64 }, { 0, 64 }
}, {
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
} };
#endif